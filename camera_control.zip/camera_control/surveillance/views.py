from django.shortcuts import render

# Create your views here.
import cv2
from django.http import StreamingHttpResponse
from django.shortcuts import render

def gen_frames():  
    cap = cv2.VideoCapture(0)  # 打开默认摄像头
    while True:
        success, frame = cap.read()  # 读取摄像头的每一帧
        if not success:
            break
        else:
            ret, buffer = cv2.imencode('.jpg', frame)  # 将帧编码为JPEG格式
            frame = buffer.tobytes()  # 转换成字节流

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')  # 返回每一帧的字节流

def video_feed(request):
    return StreamingHttpResponse(gen_frames(), content_type='multipart/x-mixed-replace; boundary=frame')
def index(request):
    return render(request, 'index.html')
